
package com.onur.dunyarehberi

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

data class CountryAPI(val name: Map<String,String>, val capital: List<String>?, val population: Long, val latlng: List<Double>, val flags: Map<String,String>, val currencies: Map<String, Map<String,String>>?)
data class WeatherResponse(val current_weather: CurrentWeather)
data class CurrentWeather(val temperature: Double, val windspeed: Double)
data class RatesResponse(val rates: Map<String, Double>)

interface ApiService {
    @GET("v3.1/all?fields=name,capital,population,latlng,flags,currencies")
    suspend fun getAllCountries(): List<CountryAPI>
    @GET("v1/forecast")
    suspend fun getWeather(@Query("latitude") lat: Double, @Query("longitude") lon: Double, @Query("current_weather") cw: Boolean = true): WeatherResponse
    @GET("latest/{base}")
    suspend fun getRates(@Path("base") base: String): RatesResponse
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val countryApi = Retrofit.Builder().baseUrl("https://restcountries.com/").addConverterFactory(GsonConverterFactory.create()).build().create(ApiService::class.java)
        val weatherApi = Retrofit.Builder().baseUrl("https://api.open-meteo.com/").addConverterFactory(GsonConverterFactory.create()).build().create(ApiService::class.java)
        val ratesApi = Retrofit.Builder().baseUrl("https://open.er-api.com/v6/").addConverterFactory(GsonConverterFactory.create()).build().create(ApiService::class.java)

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                var countries by remember { mutableStateOf<List<CountryAPI>>(emptyList()) }
                var selected by remember { mutableStateOf<CountryAPI?>(null) }
                var weather by remember { mutableStateOf<CurrentWeather?>(null) }
                var rates by remember { mutableStateOf<Map<String, Double>>(emptyMap()) }
                var search by remember { mutableStateOf("") }
                var loading by remember { mutableStateOf(true) }

                LaunchedEffect(Unit) {
                    try { countries = countryApi.getAllCountries().sortedBy { it.name["common"] }; if(countries.isNotEmpty()) selected = countries.first { it.name["common"] == "Turkey" } } catch(e: Exception) {} 
                    loading = false
                }
                LaunchedEffect(selected) {
                    selected?.let {
                        val lat = it.latlng.getOrNull(0) ?: 0.0
                        val lon = it.latlng.getOrNull(1) ?: 0.0
                        try { weather = weatherApi.getWeather(lat, lon).current_weather } catch(e: Exception){ weather = null }
                        try {
                            val currencyCode = it.currencies?.keys?.firstOrNull() ?: "USD"
                            rates = ratesApi.getRates(currencyCode).rates.filter { r -> r.key in listOf("USD","EUR","TRY","GBP","JPY","CNY") }
                        } catch(e: Exception){ rates = emptyMap() }
                    }
                }

                Scaffold(topBar = { TopAppBar(title = { Text("Dünya Rehberi 🌍") }) }) { pad ->
                    Column(Modifier.padding(pad).padding(16.dp).fillMaxSize()) {
                        OutlinedTextField(value = search, onValueChange = { search = it }, label = { Text("Ülke veya başkent ara...") }, leadingIcon = { Icon(Icons.Default.Search, null) }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(12.dp))
                        if(loading) { CircularProgressIndicator() }
                        selected?.let { c ->
                            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                                Column(Modifier.padding(16.dp)) {
                                    Row {
                                        AsyncImage(model = c.flags["png"], contentDescription = null, modifier = Modifier.size(48.dp))
                                        Spacer(Modifier.width(12.dp))
                                        Column {
                                            Text(c.name["common"] ?: "", style = MaterialTheme.typography.titleLarge)
                                            Text("Başkent: ${c.capital?.firstOrNull() ?: "Yok"} - Nüfus: ${"%,d".format(c.population)}")
                                            Text("Meridyen: ${c.latlng.getOrNull(0)}°N, ${c.latlng.getOrNull(1)}°E")
                                        }
                                    }
                                    Divider(Modifier.padding(vertical = 8.dp))
                                    Text("🌡️ Hava: ${weather?.temperature ?: "..."}°C, Rüzgar: ${weather?.windspeed ?: "..."} km/h")
                                    Spacer(Modifier.height(6.dp))
                                    Text("💱 Döviz (1 ${c.currencies?.keys?.firstOrNull()} = ):", style = MaterialTheme.typography.labelLarge)
                                    rates.forEach { (k,v) -> Text("$k: $v", style = MaterialTheme.typography.bodySmall) }
                                }
                            }
                            Spacer(Modifier.height(12.dp))
                        }
                        LazyColumn(Modifier.weight(1f)) {
                            items(countries.filter { it.name["common"]!!.contains(search, true) || (it.capital?.firstOrNull()?.contains(search, true) == true) }.take(100)) { c ->
                                Card(onClick = { selected = c }, modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                                    ListItem(headlineContent = { Text(c.name["common"]!!) }, supportingContent = { Text("${c.capital?.firstOrNull() ?: "-"} | ${c.latlng.getOrNull(1)}°E") }, leadingContent = { AsyncImage(model = c.flags["png"], contentDescription = null, modifier = Modifier.size(40.dp)) })
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
